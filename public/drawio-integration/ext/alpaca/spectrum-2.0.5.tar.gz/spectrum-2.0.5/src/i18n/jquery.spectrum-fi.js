// Spectrum Colorpicker
// Finnish (fi) localization
// https://github.com/seballot/spectrum

(function ( $ ) {

    var localization = $.spectrum.localization["fi"] = {
        cancelText: "Kumoa",
        chooseText: "Valitse"
    };

})( jQuery );
