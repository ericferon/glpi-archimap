// Spectrum Colorpicker
// Dutch (nl-nl) localization
// https://github.com/seballot/spectrum

(function ( $ ) {

    var localization = $.spectrum.localization["nl-nl"] = {
        cancelText: "Annuleer",
        chooseText: "Kies",
        clearText: "Wis kleur selectie",
        togglePaletteMoreText: 'Meer',
        togglePaletteLessText: 'Minder'
    };

})( jQuery );
